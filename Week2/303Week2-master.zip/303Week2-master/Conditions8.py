Number = int(input('Enter a number: '))
if Number < 10:
    print('Too low.')
elif Number > 10 and Number < 20:
    print('Correct.')
else:
    print('Too high.')