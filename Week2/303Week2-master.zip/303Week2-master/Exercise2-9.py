num1 = 0
num2 = 11
while(num1<=100):
    num1 = int(input("Enter a number over 100: "))

while(num2>=10):
    num2 = int(input("Enter a number less than 10: "))
answer = int(num1/num2)
print(str(num2) + " goes into " + str(num1) + " " + str(answer) + " times.")


