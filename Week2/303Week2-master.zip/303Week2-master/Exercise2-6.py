total = int(input('What is the total price of the bill? '))
diners = int(input('How many diners were there? '))
priceper = total/diners
print('Each diner must pay $' + str(round(priceper,2)) + ".")