song = input("Enter the first line of a song that you know: ")
length = len(song)
print("That song is " + str(length) + " characters long")
start = int(input("Enter a starting character: "))
end = int(input("Enter an ending character: "))
sub = song[start:end]
print("The characters of the song between those numbers are: " + sub + ".")