weight = int(input("Gimme a weight in kilograms: "))
pounds = weight*2.204
print(str(weight) + " kilograms is " + str(pounds) + " pounds.")
2.204