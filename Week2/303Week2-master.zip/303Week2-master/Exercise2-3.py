num1 = int(input('Enter a number: '))
num2 = int(input('Enter a number: '))
num3 = int(input('Enter a number: '))
answer = (num1 + num2) * num3
print('The answer is: ' + str(answer))