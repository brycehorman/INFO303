upper = input("Type any word: ").upper()
print("That word in all upercase is: " + upper + ".")