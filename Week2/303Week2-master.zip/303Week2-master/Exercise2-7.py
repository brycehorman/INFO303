days = int(input("Enter a number of days: "))
hours = days*24
minutes = hours*60
seconds = minutes*60
print("There are " + str(hours) + " hours, " + str(minutes) + " minutes, and " + str(seconds) + " seconds in " + str(days) + " days.")
