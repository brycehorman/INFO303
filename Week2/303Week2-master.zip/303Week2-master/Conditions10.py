name = input('Enter your first name')
length = len(name)
if length < 5:
    last = input('Enter your last name')
    print(name.upper() + ' ' + last.upper())
elif length >= 5:
    print(name.lower())