import math
num = int(input("Enter a number over 500: "))
root = math.sqrt(num)
print("The square root of " + str(num) + " is " + str(round(root, 2)))