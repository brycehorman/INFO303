name = input("Enter your full name: ")
length = len(name)
print("Your name has " + str(length) + " characters in it (including spaces).")