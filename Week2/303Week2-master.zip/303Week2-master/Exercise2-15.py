num = float(input("Enter a number with 5 decimal places: "))
twonum = num*2
print("Your number times two is: " + str(twonum) + ".")
print("That answer with only two decimals is: " + str(round(twonum, 2)))