import math
rad = int(input("Input the radius of a circle: "))
area = math.pi * (rad**2)
print("The area of a circle with radius " + str(rad) + " is " + str(area) + ".")