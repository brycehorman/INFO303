hours = int(input('Enter the number of hours worked: '))
rate = int(input('Enter the rate per hour: '))
answer = hours*rate
print('Pay: ' + str(answer))