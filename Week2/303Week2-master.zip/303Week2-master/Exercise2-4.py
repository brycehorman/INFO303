start = int(input('How much pizza did you start with? '))
eaten = int(input('How much pizza have you eaten? '))
end = start - eaten
if (end < 0):
    print('Sounds like you have been stealing pizza, you thief!')
elif(end == 0):
    print('You ate all your pizza. You should consider a diet')
else:
    print('You only have ' + str(end) + " slices of pizza left! Better get some more!")