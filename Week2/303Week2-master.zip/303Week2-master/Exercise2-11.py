first = input("Enter your first name: ")
last = input("Enter your last name: ")
full = first + " " + last
length = len(full)
print("The name: " + full + " has " + str(length) + " characters in it (including spaces).")