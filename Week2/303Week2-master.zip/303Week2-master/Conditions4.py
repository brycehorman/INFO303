Inclusive = int(input('Enter a number between 10 and 20'))
if Inclusive >= 10 and Inclusive <= 20:
    print('Thank you')
else:
    print('Incorrect Answer')