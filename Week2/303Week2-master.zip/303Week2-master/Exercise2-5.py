name = input("What is your name, friend? ")
age = int(input("How old are you " + name + "? "))
newage = age + 1
print(name + ' will be ' + str(newage) + ' on their next birthday!', end=' ')
if(newage >= 30):
    print('Your getting kind of old, ' + name + '.')

