import math
radius = int(input("Give me the radius of a cylinder: "))
depth = int(input("Give me the depth of a cylinder: "))
volume = math.pi * (radius**2) * depth
print("The total volume of that cylinder is: " + str(round(volume,3)))
