first = input("Enter your first name in lower case letters: ")
last = input("Enter your last name in lower case letters: ")
full = first.title() + " " + last.title()
print("Your full name in correct form is " + full + ".")