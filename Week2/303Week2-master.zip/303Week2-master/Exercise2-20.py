num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))
print(str(num1) + " divided by " + str(num2) + " is " + str(int(num1/num2)) + " remainder " + str(num1%num2) + ".")
