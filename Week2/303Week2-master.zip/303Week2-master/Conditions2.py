One = int(input('Enter a number: '))
Two = int(input('Enter a different number: '))
if One > Two:
    print(str(Two) , str(One))
else:
    print(str(One) , str(Two))