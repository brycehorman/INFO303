Color = input('Enter your favorite color')
if Color == 'red' or Color == 'Red' or Color == 'RED':
    print('I like Red too')
else:
    print('I dont like ' + Color.lower()  + ', I prefer Red.')