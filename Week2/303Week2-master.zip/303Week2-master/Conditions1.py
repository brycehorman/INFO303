try:
    hours = int(input('Number of hours worked'))
    rate = int(input('Rate per hour'))
    pay = hours * rate
    print('Pay:' + str(pay))
except:
    print('Your input is non-numeric')
