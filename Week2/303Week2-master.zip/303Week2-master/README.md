# 303Week2
Repository for my INFO 303 week 2 exercises
