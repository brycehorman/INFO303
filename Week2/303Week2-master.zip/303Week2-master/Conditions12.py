choice = int(input('1) Square \n2) Triangle \n\nEnter a number: '))
if choice == 1:
    side = int(input('Enter a side of a square: '))
    print('Area of square:', side*side)
elif choice == 2:
    base = int(input('Enter a base of a triangle: '))
    height = int(input('Enter a height of a triangle: '))
    print('Area of triangle:', (base*height)/2)
else:
    print('Invalid data entry.')