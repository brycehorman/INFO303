Number = int(input('Enter either 1, 2, or 3: '))
if Number == 1:
    print('Thank you.')
elif Number == 2:
    print('Well Done.')
elif Number == 3:
    print('Correct.')
else:
    print('Invalid data entry.')