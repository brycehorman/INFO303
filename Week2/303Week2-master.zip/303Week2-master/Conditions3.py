Number = int(input('Enter a number less than 20: '))
if Number >= 20:
    print('Too High.')
else:
    print('Thank you.')