Question = input('Is it raining outside?').lower()
if Question == 'yes':
    Response = (input('Is it windy?')).lower()
    if Response == 'yes':
        print('Its too windy for an umbrella.')
    else:
        print('Take an umbrella')
else:
    print('Enjoy your day')