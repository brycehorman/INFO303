word = input('Enter a word to be converted to pig latin: ')
word = word.lower();
if word[0:1] == 'a' or word[0:1] == 'e' or word[0:1] == 'i' or word[0:1] == 'o' or word[0:1] == 'u':
    print(word + 'ay.')
else:
    print(word[1:] + word[0] + 'ay.')