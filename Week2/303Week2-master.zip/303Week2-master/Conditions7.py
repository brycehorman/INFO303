Age = int(input('Enter your current age: '))
if Age >= 18:
    print('You can vote.')
elif Age == 17:
    print('You can learn to drive.')
elif Age == 16:
    print('You can buy a lottery ticket.')
else:
    print('You can go trick or treating.')