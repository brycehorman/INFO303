# 303Week1
Week one repository for INFO303
