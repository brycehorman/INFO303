print('What do you call a bear with no teeth?')
input('(click enter to find out)')
print('A gummy bear!')