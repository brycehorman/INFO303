height = int(input('Enter a height for the triangle: '))
for x in range(height):
    print('|', end = '')
    for y in range(x):
        print(' ', end = '')
    print("\ ")
for x in range(height):
    print('-', end = '')
