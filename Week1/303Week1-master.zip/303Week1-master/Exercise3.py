firstname = input('Enter your first name: ')
lastname = input('Enter your last name: ')
print('Hello ' + firstname + ' ' + lastname)